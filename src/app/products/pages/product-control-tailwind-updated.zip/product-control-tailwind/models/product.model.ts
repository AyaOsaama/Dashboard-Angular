export interface Product {
  _id: string;
  brand: string;
  categories: {
    main: {
      _id: string;
      name: {
        en: string;
        ar: string;
      };
    } | null | undefined;
    sub: string | null | undefined;
  };
  description: {
    ar: string;
    en: string;
  };

  material: {
    ar: string;
    en: string;
  };

  variants: ProductVariant[];

  editMode?: boolean;
}

export interface ProductVariant {
  _id?: string;
  color: {
    en: string;
    ar: string;
  };
  discountPrice?: number;
  image?: string;
  images?: string[];
  inStock: number;
  name: {
    en: string;
    ar: string;
  };
  price: number;
}

export interface ICategory {
  _id?: string;
  name: {
    en: string;
    ar: string;
  };
  description: {
    en: string;
    ar: string;
  };
  image?: string;
  subcategoriesId: string[];
}

export interface Iimagecategory extends ICategory {
  imageFile?: File | null;
  imagePreview?: string;
}

export interface SubCategory {
  _id?: string;
  name: {
    en: string;
    ar: string;
  };
  categoryId?: {
    name: {
      en: string;
      ar: string;
    };
  };
  tags?: string[];
}
