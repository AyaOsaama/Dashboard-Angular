import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { ProductService } from '../../services/product.service';
import { CategoryService } from '../../services/category.service';
import { SubcategoryService } from '../../services/subcategory.service';

@Component({
  selector: 'app-product-control',
  templateUrl: './product-control.component.html',
  providers: [MessageService]
})
export class ProductControlComponent implements OnInit {
  productForm: FormGroup;
  productId: string;
  categories: any[] = [];
  subcategories: any[] = [];
  discountPercentage = new FormControl(0);
  discountPriceError = false;
  mainImageUrl: string = '';
  additionalImageUrls: string[] = [];
  isLoading = false;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductService,
    private categoryService: CategoryService,
    private subcategoryService: SubcategoryService,
    private messageService: MessageService
  ) { }

  ngOnInit(): void {
    this.initializeForm();
    this.loadCategories();
    
    this.productId = this.route.snapshot.paramMap.get('id');
    if (this.productId) {
      this.loadProductData();
    }
  }

  initializeForm(): void {
    this.productForm = this.fb.group({
      nameEN: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
      nameAR: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
      descriptionEN: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(500)]],
      descriptionAR: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(500)]],
      brand: [''],
      materialEN: [''],
      materialAR: [''],
      mainCategory: ['', Validators.required],
      subCategory: ['', Validators.required],
      variant: this.fb.group({
        name: this.fb.group({
          en: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
          ar: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]]
        }),
        color: this.fb.group({
          en: [''],
          ar: ['']
        }),
        price: [0, [Validators.required, Validators.min(0.01)]],
        discountPrice: [0],
        inStock: [0, [Validators.required, Validators.min(0)]]
      })
    });
  }

  loadCategories(): void {
    this.isLoading = true;
    this.categoryService.getAllCategories().subscribe(
      (data) => {
        this.categories = data.categories;
        this.isLoading = false;
      },
      (error) => {
        this.isLoading = false;
        this.messageService.add({
          severity: 'error',
          summary: 'خطأ',
          detail: 'فشل في تحميل الفئات'
        });
      }
    );
  }

  onCategoryChange(event: any): void {
    const categoryId = event.value;
    if (categoryId) {
      this.loadSubcategories(categoryId);
      this.productForm.get('subCategory').setValue(null);
    } else {
      this.subcategories = [];
    }
  }

  loadSubcategories(categoryId: string): void {
    this.isLoading = true;
    this.subcategoryService.getSubcategoriesByCategory(categoryId).subscribe(
      (data) => {
        this.subcategories = data.subcategories;
        this.isLoading = false;
      },
      (error) => {
        this.isLoading = false;
        this.messageService.add({
          severity: 'error',
          summary: 'خطأ',
          detail: 'فشل في تحميل الفئات الفرعية'
        });
      }
    );
  }

  loadProductData(): void {
    this.isLoading = true;
    this.productService.getProductById(this.productId).subscribe(
      (data) => {
        const product = data.product;
        
        // Set main product fields
        this.productForm.patchValue({
          nameEN: product.variants[0]?.name?.en || '',
          nameAR: product.variants[0]?.name?.ar || '',
          descriptionEN: product.description?.en || '',
          descriptionAR: product.description?.ar || '',
          brand: product.brand || '',
          materialEN: product.material?.en || '',
          materialAR: product.material?.ar || '',
          mainCategory: product.categories?.main || '',
          subCategory: product.categories?.sub || ''
        });

        // Load subcategories if main category exists
        if (product.categories?.main) {
          this.loadSubcategories(product.categories.main);
        }

        // Set variant fields if exists
        if (product.variants && product.variants.length > 0) {
          const variant = product.variants[0];
          this.productForm.get('variant').patchValue({
            name: {
              en: variant.name?.en || '',
              ar: variant.name?.ar || ''
            },
            color: {
              en: variant.color?.en || '',
              ar: variant.color?.ar || ''
            },
            price: variant.price || 0,
            discountPrice: variant.discountPrice || 0,
            inStock: variant.inStock || 0
          });

          // Calculate discount percentage
          if (variant.price && variant.discountPrice) {
            const discount = ((variant.price - variant.discountPrice) / variant.price) * 100;
            this.discountPercentage.setValue(Math.round(discount));
          }

          // Set images
          this.mainImageUrl = variant.image || '';
          this.additionalImageUrls = variant.images || [];
        }

        this.isLoading = false;
      },
      (error) => {
        this.isLoading = false;
        this.messageService.add({
          severity: 'error',
          summary: 'خطأ',
          detail: 'فشل في تحميل بيانات المنتج'
        });
      }
    );
  }

  updateDiscountPrice(): void {
    const variantGroup = this.productForm.get('variant');
    const price = variantGroup.get('price').value || 0;
    const discountPercent = this.discountPercentage.value || 0;
    
    if (price > 0 && discountPercent > 0) {
      const discountPrice = price - (price * discountPercent / 100);
      variantGroup.get('discountPrice').setValue(discountPrice);
      
      // Validate discount price
      this.discountPriceError = discountPrice >= price;
    } else {
      variantGroup.get('discountPrice').setValue(0);
      this.discountPriceError = false;
    }
  }

  onMainImageUpload(event: any): void {
    const files = event.files;
    if (files && files.length > 0) {
      const file = files[0];
      this.uploadImage(file, 'main');
    }
  }

  onAdditionalImagesUpload(event: any): void {
    const files = event.files;
    if (files && files.length > 0) {
      for (const file of files) {
        this.uploadImage(file, 'additional');
      }
    }
  }

  uploadImage(file: File, type: 'main' | 'additional'): void {
    this.isLoading = true;
    this.productService.uploadImage(file).subscribe(
      (response) => {
        if (type === 'main') {
          this.mainImageUrl = response.imageUrl;
        } else {
          this.additionalImageUrls.push(response.imageUrl);
        }
        this.isLoading = false;
        this.messageService.add({
          severity: 'success',
          summary: 'تم',
          detail: 'تم رفع الصورة بنجاح'
        });
      },
      (error) => {
        this.isLoading = false;
        this.messageService.add({
          severity: 'error',
          summary: 'خطأ',
          detail: 'فشل في رفع الصورة'
        });
      }
    );
  }

  removeAdditionalImage(index: number): void {
    this.additionalImageUrls.splice(index, 1);
  }

  saveProduct(): void {
    if (this.productForm.invalid || this.discountPriceError) {
      this.messageService.add({
        severity: 'warn',
        summary: 'تحذير',
        detail: 'يرجى تصحيح الأخطاء في النموذج قبل الحفظ'
      });
      
      // Mark all fields as touched to show validation errors
      this.markFormGroupTouched(this.productForm);
      return;
    }

    // Show loading message
    this.isLoading = true;
    this.messageService.add({
      severity: 'info',
      summary: 'جاري الحفظ',
      detail: 'يتم الآن حفظ بيانات المنتج...',
      key: 'saving',
      sticky: true
    });

    const formData = this.productForm.value;
    
    // Prepare product data
    const productData = {
      brand: formData.brand,
      description: {
        en: formData.descriptionEN,
        ar: formData.descriptionAR
      },
      material: {
        en: formData.materialEN,
        ar: formData.materialAR
      },
      categories: {
        main: formData.mainCategory,
        sub: formData.subCategory
      },
      variants: [{
        name: formData.variant.name,
        color: formData.variant.color,
        price: formData.variant.price,
        discountPrice: formData.variant.discountPrice,
        inStock: formData.variant.inStock,
        image: this.mainImageUrl,
        images: this.additionalImageUrls
      }]
    };

    // Update or create product
    const request = this.productId
      ? this.productService.updateProduct(this.productId, productData)
      : this.productService.createProduct(productData);

    request.subscribe(
      (response) => {
        // Clear saving message
        this.messageService.clear('saving');
        this.isLoading = false;
        
        this.messageService.add({
          severity: 'success',
          summary: 'تم',
          detail: this.productId ? 'تم تحديث المنتج بنجاح' : 'تم إنشاء المنتج بنجاح'
        });

        // Navigate back to products list after a short delay
        setTimeout(() => {
          this.router.navigate(['/products']);
        }, 1500);
      },
      (error) => {
        // Clear saving message
        this.messageService.clear('saving');
        this.isLoading = false;
        
        this.messageService.add({
          severity: 'error',
          summary: 'خطأ',
          detail: error.error?.message || 'حدث خطأ أثناء حفظ المنتج'
        });
      }
    );
  }

  // Helper method to mark all controls in a form group as touched
  private markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
}
